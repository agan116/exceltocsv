<?php
$txt = "Test user id date";
//$myfile = file_put_contents('cron-logs.txt', $txt.PHP_EOL , FILE_APPEND | LOCK_EX);
$test = '/home/mairsand/public_html/templates/tabulizer/data/growth-fund-data.xlsx';
copy('/home/mairsand/public_html_beta/templates/tabulizer/data/small-cap-fund-data.xlsx', '/home/mairsand/public_html/templates/tabulizer/data/small-cap-fund-data.xlsx');