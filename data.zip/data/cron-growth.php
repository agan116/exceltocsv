<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
$faadsfa
      //  copy('/home/mairsand/public_html_beta/templates/tabulizer/data/growth-fund-data.xlsx', '/home/mairsand/public_html/templates/tabulizer/data/growth-fund-data.xlsx');
                 //copy('/home/mairsand/public_html_beta/datafeed/MP_Daily_FTP.csv', '/home/mairsand/public_html/datafeed/MP_Daily_FTP.csv');
                //copy('/home/mairsand/public_html_beta/datafeed/MP_Quarterly_FTP.csv', '/home/mairsand/public_html/datafeed/MP_Quarterly_FTP.csv');
      //  copy('/home/mairsand/public_html_beta/templates/tabulizer/data/balanced-fund-data.xlsx', '/home/mairsand/public_html/templates/tabulizer/data/balanced-fund-data.xlsx');
      //  copy('/home/mairsand/public_html_beta/templates/tabulizer/data/small-cap-fund-data.xlsx', '/home/mairsand/public_html/templates/tabulizer/data/small-cap-fund-data.xlsx');

		$excel_lib = '/var/www/mp/cronfiles/data/Classes/PHPExcel/IOFactory.php';
		include($excel_lib);
		$filearray = array('growth-fund-data.xlsx','MP_Quarterly_FTP.csv','MP_Daily_FTP.csv');

			// open file
					//$file = fopen(dirname(__FILE__).'/'.$filearray[0],"r");
			//$file2 = fopen('/home/mairsand/public_html/datafeed/'.$filearray[1],"r");
			//$file_daily = fopen('/home/mairsand/public_html/datafeed/'.$filearray[2],"r");

			$file2 = fopen(dirname(__FILE__).'/'.$filearray[1],"r");
			$file_daily = fopen(dirname(__FILE__).'/'.$filearray[2],"r");

			if (!$file2) {
				echo "File not exisit";
			}

			$csv = array();
			$omit = array();
			$omit2 = array(1,2,4,6);
			$omit3 = array(2,3,4);
			
			 try {
    $inputFileType1 = PHPExcel_IOFactory::identify($filearray[0]);
 
    $objReader1 = PHPExcel_IOFactory::createReader($inputFileType1);

    $objPHPExcel1 = $objReader1->load($filearray[0]);

  } catch (Exception $e) {
    die('Error loading file "' . pathinfo($filearray[0], PATHINFO_BASENAME) . '": ' . 
        $e->getMessage());
  }
	  $sheet1 = $objPHPExcel1->getSheet(0);

	  $highestRow1 = $sheet1->getHighestRow();

	  $highestColumn1 = $sheet1->getHighestColumn();

	  $rowData1 = array();

  for ($row1 = 1; $row1 <= $highestRow1; $row1++) { 
    $rowData1[] = $sheet1->rangeToArray('A' . $row1 . ':' . $highestColumn1 . $row1, null, true, true);
  }

  foreach($rowData1 AS $k => $v){
	  foreach ($v AS $fk => $fv){
		  $csv[] = $fv;
		  }
	  }

   
					while( ($row2 = fgetcsv($file2)) !== FALSE){
						 $array_without2 = array_diff_key($row2, array_flip($omit2));		 
						 $csvnew[] = $array_without2;
					} 
					while( ($row3 = fgetcsv($file_daily)) !== FALSE){
						 $array_without3 = array_diff_key($row3, array_flip($omit));		 
						 $csv_daily[] = $array_without3;
					} 

						$as_of = 'As of '.$csv[1][1];
						$as_of_per = 'As of '.$csvnew[1][0];
						$per1 = $csv[9][1];
						$per2 = $csv[13][1];
						$per3 = $csv[17][1];
						$per4 = $csv[21][1];
						$per5 = $csv[25][1];
						$per6 = $csv[29][1];
						$per7 = $csv[33][1];
						$yr1 = $csv[9][3];
						$yr2 = $csv[13][3];
						$yr3 = $csv[17][3];
						$yr4 = $csv[21][3];
						$yr5 = $csv[25][3];
						$yr6 = $csv[29][3];
						$yr7 = $csv[33][3];
						$mpgf1 = $csv[10][1];
						$mpgf2 = $csv[14][1];
						$mpgf3 = $csv[18][1];
						$mpgf4 = $csv[22][1];
						$mpgf5 = $csv[26][1];
						$mpgf6 = $csv[30][1];
						$mpgf7 = $csv[34][1];
						$sp1 = $csv[12][1];
						$sp2 = $csv[16][1];
						$sp3 = $csv[20][1];
						$sp4 = $csv[24][1];
						$sp5 = $csv[28][1];
						$sp6 = $csv[32][1];
						$sp7 = $csv[36][1];
						$lmc1 = $csv[11][1];
						$lmc2 = $csv[15][1];
						$lmc3 = $csv[19][1];
						$lmc4 = $csv[23][1];
						$lmc5 = $csv[27][1];
						$lmc6 = $csv[31][1];
						$lmc7 = $csv[35][1];
						$sweight1 = $csv[88][0];
						$sweight2 = $csv[89][0];
						$sweight3 = $csv[90][0];
						$sweight4 = $csv[91][0];
						$sweight5 = $csv[92][0];
						$sweight6 = $csv[93][0];
						$sweight7 = $csv[94][0];
						$sweight8 = $csv[95][0];
						$sweight9 = $csv[96][0];
						$sweight10 = $csv[97][0];
						$sweight11 = $csv[98][0];
						$sweight12 = $csv[99][0];
						$sweightv1 = number_format($csv[88][1],1);
						$sweightv2 = number_format($csv[89][1],1);
						$sweightv3 = number_format($csv[90][1],1);
						$sweightv4 = number_format($csv[91][1],1);
						$sweightv5 = number_format($csv[92][1],1);
						$sweightv6 = number_format($csv[93][1],1);
						$sweightv7 = number_format($csv[94][1],1);
						$sweightv8 = number_format($csv[95][1],1);
						$sweightv9 = number_format($csv[96][1],1);
						$sweightv10 = number_format($csv[97][1],1);
						$sweightv11 = number_format($csv[98][1],1);
						$sweightv12 = number_format($csv[99][1],1);
						$swv1 = $csv[158][1];
						$swv2 = $csv[159][1];
						$swv3 = $csv[160][1];
						$swv4 = $csv[161][1];
						$swv5 = $csv[162][1];
						$swv6 = $csv[163][1];
						$swv7 = $csv[164][1];
						$swv8 = $csv[165][1];
						$swv9 = $csv[166][1];
						$swv10 = $csv[167][1];
						$swv11 = $csv[168][1];
						$hold_title = $csv[102][0];
						$hold_l1 = $csv[103][0];
						$hold_l2 = $csv[104][0];
						$hold_l3 = $csv[105][0];
						$hold_l4 = $csv[106][0];
						$hold_l5 = $csv[107][0];
						$hold_l6 = $csv[108][0];
						$hold_l7 = $csv[109][0];
						$hold_l8 = $csv[110][0];
						$hold_l9 = $csv[111][0];
						$hold_l10 = $csv[112][0];
						$hold_v1 = number_format($csv[103][1],1);
						$hold_v2 = number_format($csv[104][1],1);
						$hold_v3 = number_format($csv[105][1],1);
						$hold_v4 = number_format($csv[106][1],1);
						$hold_v5 = number_format($csv[107][1],1);
						$hold_v6 = number_format($csv[108][1],1);
						$hold_v7 = number_format($csv[109][1],1);
						$hold_v8 = number_format($csv[110][1],1);
						$hold_v9 = number_format($csv[111][1],1);
						$hold_v10 = number_format($csv[112][1],1);
						
						$bal_hold_l1 = $csv_bal[103][0];
						$bal_hold_l2 = $csv_bal[104][0];
						$bal_hold_l3 = $csv_bal[105][0];
						$bal_hold_l4 = $csv_bal[106][0];
						$bal_hold_l5 = $csv_bal[107][0];
						$bal_hold_l6 = $csv_bal[108][0];
						$bal_hold_l7 = $csv_bal[109][0];
						$bal_hold_l8 = $csv_bal[110][0];
						$bal_hold_l9 = $csv_bal[111][0];
						$bal_hold_l10 = $csv_bal[112][0];
						$bal_hold_v1 = number_format($csv_bal[103][1],1);
						$bal_hold_v2 = number_format($csv_bal[104][1],1);
						$bal_hold_v3 = number_format($csv_bal[105][1],1);
						$bal_hold_v4 = number_format($csv_bal[106][1],1);
						$bal_hold_v5 = number_format($csv_bal[107][1],1);
						$bal_hold_v6 = number_format($csv_bal[108][1],1);
						$bal_hold_v7 = number_format($csv_bal[109][1],1);
						$bal_hold_v8 = number_format($csv_bal[110][1],1);
						$bal_hold_v9 = number_format($csv_bal[111][1],1);
						$bal_hold_v10 = number_format($csv_bal[112][1],1);
						
						$small_hold_l1 = $csv_small[103][0];
						$small_hold_l2 = $csv_small[104][0];
						$small_hold_l3 = $csv_small[105][0];
						$small_hold_l4 = $csv_small[106][0];
						$small_hold_l5 = $csv_small[107][0];
						$small_hold_l6 = $csv_small[108][0];
						$small_hold_l7 = $csv_small[109][0];
						$small_hold_l8 = $csv_small[110][0];
						$small_hold_l9 = $csv_small[111][0];
						$small_hold_l10 = $csv_small[112][0];
						$small_hold_v1 = number_format($csv_small[103][1],1);
						$small_hold_v2 = number_format($csv_small[104][1],1);
						$small_hold_v3 = number_format($csv_small[105][1],1);
						$small_hold_v4 = number_format($csv_small[106][1],1);
						$small_hold_v5 = number_format($csv_small[107][1],1);
						$small_hold_v6 = number_format($csv_small[108][1],1);
						$small_hold_v7 = number_format($csv_small[109][1],1);
						$small_hold_v8 = number_format($csv_small[110][1],1);
						$small_hold_v9 = number_format($csv_small[111][1],1);
						$small_hold_v10 = number_format($csv_small[112][1],1);
						
						$mcap1 = $csv[131][0].' '.$csv[131][1];
						$mcap2 = $csv[132][0].' '.$csv[132][1];
						$mcap3 = $csv[133][0].' '.$csv[133][1];
						$mcapv1 = trim($csv[131][1],'%');
						$mcapv2 = trim($csv[132][1],'%');
						$mcapv3 = trim($csv[133][1],'%');
						$geo1 = $csv[138][0].' '.$csv[138][1];
						$geo2 = $csv[139][0].' '.$csv[139][1];
						$geo3 = $csv[140][0].' '.$csv[140][1];
						$geov1 = trim($csv[138][1],'%');
						$geov2 = trim($csv[139][1],'%');
						$geov3 = trim($csv[140][1],'%');
						$asset1 = $csv[144][0].' '.$csv[144][1];
						$asset2 = $csv[149][0].' '.$csv[149][1];
						$assetv1 = trim($csv[144][1],'%');
						$assetv2 = trim($csv[149][1],'%');
						$growth_date_string = $csv[1][1];
						$growth_date = date_format('m/d/Y', $growth_date_string);
						$ff_date = 'As of '.$growth_date.':';
						$bal_ff_date = 'As of '.$csv_bal[1][1].':';
						$small_ff_date = 'As of '.$csv_small[1][1].':';

						$ff1 = 'Ticker';
						$ff2 = 'Inception Date';
						$ff3 = 'Style';
						$ff4 = 'Holdings';
						$ff5 = 'Annualized Turnover<sup>5</sup>';
						$ff6 = 'Expense Ratio';
						$ff7 = 'Active Share<sup>6</sup>';
						$ff8 = 'Sharpe Ratio<sup>7</sup>';
						$ff9 = 'Net Asset Value<sup>8</sup>';
						$ff10 = 'Wtd. Ave. Market Cap<sup>9</sup>';
						$ff11 = '30-Day SEC Yield<sup>10</sup>';
						$ff12 = 'Total Net Assets';
						$ff13 = 'Sales Charge<sup>1</sup>';
						$ff14 = 'Min. Initial Investment';
						$ff15 = 'Min. Initial IRA Investment';
						$ff16 = 'Subsequent Investment';
						$ff17 = 'Income Distributions';
						$ff18 = 'Capital Gains Distributions';
						
						$ffv1 = $csv[63][1];
						$ffv2 = $csv[64][1];
						$ffv3 = $csv[65][1];
						$ffv4 = $csv[66][1];
						$ffv5 = $csv[67][1];
						$ffv6 = $csv[68][1];
						$ffv7 = $csv[70][1];
						$ffv8 = $csv[71][1];
						$ffv9 = $csv[72][1];
						$ffv10 = $csv[73][1];
						$ffv11 = $csv[75][1];
						$ffv12 = $csv[78][1];
						$ffv13 = $csv[79][1];
						$ffv14 = $csv[80][1];
						$ffv15 = $csv[81][1];
						$ffv16 = $csv[82][1];
						$ffv17 = $csv[83][1];
						$ffv18 = $csv[84][1];
						
					
						$morn1 = 'As of '.$csv[1][1].' among Large Blend Funds based on risk-adjusted Returns.';
						$morn_sr1 = $csv[40][1];
						if($morn_sr1 == '1'){$morn_sr_star1='<img src=/images/1Stars.png alt=1star >';}elseif($morn_sr1 == '2'){$morn_sr_star1='<img src=/images/2Stars.png alt=2star >';}elseif($morn_sr1 == '3'){$morn_sr_star1='<img src=/images/3Stars.png alt=3star >';}elseif($morn_sr1 == '4'){$morn_sr_star1='<img src=/images/4Stars.png alt=4star >';}elseif($morn_sr1 == '5'){$morn_sr_star1='<img src=/images/5Stars.png alt=5star >';}else{$morn_sr_star1 = '-';}
						$morn_sr2 = $csv[41][1];
						if($morn_sr2 == '1'){$morn_sr_star2='<img src=/images/1Stars.png alt=1star >';}elseif($morn_sr2 == '2'){$morn_sr_star2='<img src=/images/2Stars.png alt=2star >';}elseif($morn_sr2 == '3'){$morn_sr_star2='<img src=/images/3Stars.png alt=3star >';}elseif($morn_sr2 == '4'){$morn_sr_star2='<img src=/images/4Stars.png alt=4star >';}elseif($morn_sr2 == '5'){$morn_sr_star2='<img src=/images/5Stars.png alt=5star >';}else{$morn_sr_star2 = '-';}
						$morn_sr3 = $csv[42][1];
						if($morn_sr3 == '1'){$morn_sr_star3='<img src=/images/1Stars.png alt=1star >';}elseif($morn_sr3 == '2'){$morn_sr_star3='<img src=/images/2Stars.png alt=2star >';}elseif($morn_sr3 == '3'){$morn_sr_star3='<img src=/images/3Stars.png alt=3star >';}elseif($morn_sr3 == '4'){$morn_sr_star3='<img src=/images/4Stars.png alt=4star >';}elseif($morn_sr3 == '5'){$morn_sr_star3='<img src=/images/5Stars.png alt=5star >';}else{$morn_sr_star3 = '-';}
						$morn_sr4 = $csv[43][1];
						if($morn_sr4 == '1'){$morn_sr_star4='<img src=/images/1Stars.png alt=1star >';}elseif($morn_sr4 == '2'){$morn_sr_star4='<img src=/images/2Stars.png alt=2star >';}elseif($morn_sr4 == '3'){$morn_sr_star4='<img src=/images/3Stars.png alt=3star >';}elseif($morn_sr4 == '4'){$morn_sr_star4='<img src=/images/4Stars.png alt=4star >';}elseif($morn_sr4 == '5'){$morn_sr_star4='<img src=/images/5Stars.png alt=5star >';}else{$morn_sr_star4 = '-';}
						$morn_sr5 = $csv[44][1];
						if($morn_sr5 == '1'){$morn_sr_star5='<img src=/images/1Stars.png alt=1star >';}elseif($morn_sr5 == '2'){$morn_sr_star5='<img src=/images/2Stars.png alt=2star >';}elseif($morn_sr5 == '3'){$morn_sr_star5='<img src=/images/3Stars.png alt=3star >';}elseif($morn_sr5 == '4'){$morn_sr_star5='<img src=/images/4Stars.png alt=4star >';}elseif($morn_sr5 == '5'){$morn_sr_star5='<img src=/images/5Stars.png alt=5star >';}else{$morn_sr_star5 = '-';}
						$morn_sr6 = $csv[44][3];
						if($morn_sr6 == '1'){$morn_sr_star6='<img src=/images/1Stars.png alt=1star >';}elseif($morn_sr6 == '2'){$morn_sr_star6='<img src=/images/2Stars.png alt=2star >';}elseif($morn_sr6 == '3'){$morn_sr_star6='<img src=/images/3Stars.png alt=3star >';}elseif($morn_sr6 == '4'){$morn_sr_star6='<img src=/images/4Stars.png alt=4star >';}elseif($morn_sr6 == '5'){$morn_sr_star6='<img src=/images/5Stars.png alt=5star >';}else{$morn_sr_star6 = '-';}
						$morn_fc1 = $csv[45][1];
						$morn_fc2 = $csv[46][1];
						$morn_fc3 = $csv[47][1];
						$morn_fc4 = $csv[48][1];
						$morn_fc5 = $csv[49][1];
						$morn_fc6 = $csv[49][3];
						$morn_pr1 = $csv[50][1];
						$morn_pr2 = $csv[51][1];
						$morn_pr3 = $csv[52][1];
						$morn_pr4 = $csv[53][1];
						$morn_pr5 = $csv[54][1];
						$morn_pr6 = $csv[54][3];
						$morn_fic1 = $csv[55][1];
						$morn_fic2 = $csv[56][1];
						$morn_fic3 = $csv[57][1];
						$morn_fic4 = $csv[58][1];
						$morn_fic5 = $csv[59][1];
						$morn_fic6 = $csv[59][3];
						
						$amp1 = 'Mairs & Power Growth Fund<sup>2</sup>';
						$asp1 = 'S&P 500 TR Index<sup>3</sup>';
						$alm1 = 'Lipper Multi-Cap Core Index<sup>4</sup>';
						/* overview */
						$over_label = array('FUND/INDEX', '1 YR', '5 YR', '10 YR', '20 YR',	'SINCE INCEPTION');
						$over_amp1 = 'Mairs & Power Growth Fund<sup>1</sup>';
					    if(is_numeric($csvnew[1][5])){ $over_amp2 = number_format($csvnew[1][5],2); }else{ $over_amp2 = '-';  }
                        if(is_numeric($csvnew[1][7])){ $over_amp3 = number_format($csvnew[1][7],2); }else{ $over_amp3 = '-';  }
                        if(is_numeric($csvnew[1][8])){ $over_amp4 = number_format($csvnew[1][8],2); }else{ $over_amp4 = '-';  }
                        if(is_numeric($csvnew[1][9])){ $over_amp5 = number_format($csvnew[1][9],2); }else{ $over_amp5 = '-';  }
                        if(is_numeric($csvnew[1][10])){ $over_amp6 = number_format($csvnew[1][10],2); }else{ $over_amp6 = '-';  }
						if(is_numeric($over_amp2)){ $over_amp_chart2 = $over_amp2; }else{ $over_amp_chart2 = '0';  }
						if(is_numeric($over_amp3)){ $over_amp_chart3 = $over_amp3; }else{ $over_amp_chart3 = '0';  }
						if(is_numeric($over_amp4)){ $over_amp_chart4 = $over_amp4; }else{ $over_amp_chart4 = '0';  }
						if(is_numeric($over_amp5)){ $over_amp_chart5 = $over_amp5; }else{ $over_amp_chart5 = '0';  }
						if(is_numeric($over_amp6)){ $over_amp_chart6 = $over_amp6; }else{ $over_amp_chart6 = '0';  }
						$over_asp1 = 'S&P 500 TR Index<sup>2</sup>';
						if(is_numeric($csvnew[3][5])){ $over_asp2 = number_format($csvnew[3][5],2); }else{ $over_asp2 = '-';  }
                        if(is_numeric($csvnew[3][7])){ $over_asp3 = number_format($csvnew[3][7],2); }else{ $over_asp3 = '-';  }
                        if(is_numeric($csvnew[3][8])){ $over_asp4 = number_format($csvnew[3][8],2); }else{ $over_asp4 = '-';  }
                        if(is_numeric($csvnew[3][9])){ $over_asp5 = number_format($csvnew[3][9],2); }else{ $over_asp5 = '-';  }
                        if(is_numeric($csv[200][1])){ $over_asp6 = number_format($csv[200][1],2); }else{ $over_asp6 = '-';  }
						if(is_numeric($over_asp2)){ $over_asp_chart2 = $over_asp2; }else{ $over_asp_chart2 = '0';  }
						if(is_numeric($over_asp3)){ $over_asp_chart3 = $over_asp3; }else{ $over_asp_chart3 = '0';  }
						if(is_numeric($over_asp4)){ $over_asp_chart4 = $over_asp4; }else{ $over_asp_chart4 = '0';  }
						if(is_numeric($over_asp5)){ $over_asp_chart5 = $over_asp5; }else{ $over_asp_chart5 = '0';  }
						if(is_numeric($over_asp6)){ $over_asp_chart6 = $over_asp6; }else{ $over_asp_chart6 = '0';  }
						$over_alm1 = 'Lipper Multi-Cap Core Index<sup>3</sup>';
						if(is_numeric($csvnew[2][5])){ $over_alm2 = number_format($csvnew[2][5],2); }else{ $over_alm2 = '-';  }
                        if(is_numeric($csvnew[2][7])){ $over_alm3 = number_format($csvnew[2][7],2); }else{ $over_alm3 = '-';  }
                        if(is_numeric($csvnew[2][8])){ $over_alm4 = number_format($csvnew[2][8],2); }else{ $over_alm4 = '-';  }
                        if(is_numeric($csvnew[2][9])){ $over_alm5 = number_format($csvnew[2][9],2); }else{ $over_alm5 = '-';  }
						if(is_numeric($csvnew[2][10])){ $over_alm6 = number_format($csvnew[2][10],2); }else{ $over_alm6 = '-';  }
						if(is_numeric($over_alm2)){ $over_alm_chart2 = $over_alm2; }else{ $over_alm2 = '0';  }
						if(is_numeric($over_alm3)){ $over_alm_chart3 = $over_alm3; }else{ $over_alm_chart3 = '0';  }
						if(is_numeric($over_alm4)){ $over_alm_chart4 = $over_alm4; }else{ $over_alm_chart4 = '0';  }
						if(is_numeric($over_alm5)){ $over_alm_chart5 = $over_alm5; }else{ $over_alm_chart5 = '0';  }
						if(is_numeric($over_alm6)){ $over_alm_chart6 = $over_alm6; }else{ $over_alm_chart6 = '0';  }						
						$over_bal_mp1 = 'Mairs & Power Balanced Fund<sup>1</sup>';
						if(is_numeric($csvnew[4][5])){ $over_bal_mp2 = number_format($csvnew[4][5],2); }else{ $over_bal_mp2 = '-';  }
                        if(is_numeric($csvnew[4][7])){ $over_bal_mp3 = number_format($csvnew[4][7],2); }else{ $over_bal_mp3 = '-';  }
                        if(is_numeric($csvnew[4][8])){ $over_bal_mp4 = number_format($csvnew[4][8],2); }else{ $over_bal_mp4 = '-';  }
                        if(is_numeric($csvnew[4][9])){ $over_bal_mp5 = number_format($csvnew[4][9],2); }else{ $over_bal_mp5 = '-';  }
                        if(is_numeric($csvnew[4][10])){ $over_bal_mp6 = number_format($csvnew[4][10],2); }else{ $over_bal_mp6 = '-';  }
						if(is_numeric($over_bal_mp2)){ $over_bal_mp_chart2 = $over_bal_mp2; }else{ $over_bal_mp_chart2 = '0';  }
						if(is_numeric($over_bal_mp3)){ $over_bal_mp_chart3 = $over_bal_mp3; }else{ $over_bal_mp_chart3 = '0';  }
						if(is_numeric($over_bal_mp4)){ $over_bal_mp_chart4 = $over_bal_mp4; }else{ $over_bal_mp_chart4 = '0';  }
						if(is_numeric($over_bal_mp5)){ $over_bal_mp_chart5 = $over_bal_mp5; }else{ $over_bal_mp_chart5 = '0';  }
						if(is_numeric($over_bal_mp6)){ $over_bal_mp_chart6 = $over_bal_mp6; }else{ $over_bal_mp_chart6 = '0';  }
						$over_bal_com1 = 'Composite Index<sup>4</sup>';
						if(is_numeric($csvnew[6][5])){ $over_bal_com2 = number_format($csvnew[6][5],2); }else{ $over_bal_com2 = '-';  }
                        if(is_numeric($csvnew[6][7])){ $over_bal_com3 = number_format($csvnew[6][7],2); }else{ $over_bal_com3 = '-';  }
                        if(is_numeric($csvnew[6][8])){ $over_bal_com4 = number_format($csvnew[6][8],2); }else{ $over_bal_com4 = '-';  }
                        if(is_numeric($csvnew[6][9])){ $over_bal_com5 = number_format($csvnew[6][9],2); }else{ $over_bal_com5 = '-';  }
                        if(is_numeric($csv_bal[200][1])){ $over_bal_com6 = number_format($csv_bal[200][1],2); }else{ $over_bal_com6 = '-';  }
						if(is_numeric($over_bal_com2)){ $over_bal_com_chart2 = $over_bal_com2; }else{ $over_bal_com_chart2 = '0';  }
						if(is_numeric($over_bal_com3)){ $over_bal_com_chart3 = $over_bal_com3; }else{ $over_bal_com_chart3 = '0';  }
						if(is_numeric($over_bal_com4)){ $over_bal_com_chart4 = $over_bal_com4; }else{ $over_bal_com_chart4 = '0';  }
						if(is_numeric($over_bal_com5)){ $over_bal_com_chart5 = $over_bal_com5; }else{ $over_bal_com_chart5 = '0';  }
						if(is_numeric($over_bal_com6)){ $over_bal_com_chart6 = $over_bal_com6; }else{ $over_bal_com_chart6 = '0';  }
						$over_bal_morn1 = 'Morningstar Category<sup>5</sup>';
						if(is_numeric($csvnew[12][5])){ $over_bal_morn2 = number_format($csvnew[12][5],2); }else{ $over_bal_morn2 = '-';  }
                        if(is_numeric($csvnew[12][7])){ $over_bal_morn3 = number_format($csvnew[12][7],2); }else{ $over_bal_morn3 = '-';  }
                        if(is_numeric($csvnew[12][8])){ $over_bal_morn4 = number_format($csvnew[12][8],2); }else{ $over_bal_morn4 = '-';  }
                        if(is_numeric($csvnew[12][9])){ $over_bal_morn5 = number_format($csvnew[12][9],2); }else{ $over_bal_morn5 = '-';  }
                        if(is_numeric($csvnew[12][10])){ $over_bal_morn6 = number_format($csvnew[12][10],2); }else{ $over_bal_morn6 = '-';  }
						if(is_numeric($over_bal_morn2)){ $over_bal_morn_chart2 = $over_bal_morn2; }else{ $over_bal_morn_chart2 = '0';  }
						if(is_numeric($over_bal_morn3)){ $over_bal_morn_chart3 = $over_bal_morn3; }else{ $over_bal_morn_chart3 = '0';  }
						if(is_numeric($over_bal_morn4)){ $over_bal_morn_chart4 = $over_bal_morn4; }else{ $over_bal_morn_chart4 = '0';  }
						if(is_numeric($over_bal_morn5)){ $over_bal_morn_chart5 = $over_bal_morn5; }else{ $over_bal_morn_chart5 = '0';  }
						if(is_numeric($over_bal_morn6)){ $over_bal_morn_chart6 = $over_bal_morn6; }else{ $over_bal_morn_chart6 = '0';  }
						$over_bal_sp1 = 'S&P 500 TR Index<sup>2</sup>';
						if(is_numeric($csvnew[7][5])){ $over_bal_sp2 = number_format($csvnew[7][5],2); }else{ $over_bal_sp2 = '-';  }
                        if(is_numeric($csvnew[7][7])){ $over_bal_sp3 = number_format($csvnew[7][7],2); }else{ $over_bal_sp3 = '-';  }
                        if(is_numeric($csvnew[7][8])){ $over_bal_sp4 = number_format($csvnew[7][8],2); }else{ $over_bal_sp4 = '-';  }
                        if(is_numeric($csvnew[7][9])){ $over_bal_sp5 = number_format($csvnew[7][9],2); }else{ $over_bal_sp5 = '-';  }
                        if(is_numeric($csvnew[7][10])){ $over_bal_sp6 = number_format($csvnew[7][10],2); }else{ $over_bal_sp6 = '-';  }

						$over_bal_bloom1 = 'Bloomberg Barclays U.S.Govt/Credit Bond Index<sup>6</sup>';
						if(is_numeric($csvnew[5][5])){ $over_bal_bloom2 = number_format($csvnew[5][5],2); }else{ $over_bal_bloom2 = '-';  }
                        if(is_numeric($csvnew[5][7])){ $over_bal_bloom3 = number_format($csvnew[5][7],2); }else{ $over_bal_bloom3 = '-';  }
                        if(is_numeric($csvnew[5][8])){ $over_bal_bloom4 = number_format($csvnew[5][8],2); }else{ $over_bal_bloom4 = '-';  }
                        if(is_numeric($csvnew[5][9])){ $over_bal_bloom5 = number_format($csvnew[5][9],2); }else{ $over_bal_bloom5 = '-';  }
                        if(is_numeric($csvnew[5][10])){ $over_bal_bloom6 = number_format($csvnew[5][10],2); }else{ $over_bal_bloom6 = '-';  }
						$over_sc_mp1 = 'Mairs & Power Small Cap Fund<sup>1</sup>'; 
						if(is_numeric($csvnew[8][5])){ $over_sc_mp2 = number_format($csvnew[8][5],2); }else{ $over_sc_mp2 = '-';  }
                        if(is_numeric($csvnew[8][7])){ $over_sc_mp3 = number_format($csvnew[8][7],2); }else{ $over_sc_mp3 = '-';  }
                        if(is_numeric($csvnew[8][8])){ $over_sc_mp4 = number_format($csvnew[8][8],2); }else{ $over_sc_mp4 = '-';  }
                        if(is_numeric($csvnew[8][9])){ $over_sc_mp5 = number_format($csvnew[8][9],2); }else{ $over_sc_mp5 = '-';  }
                        if(is_numeric($csvnew[8][10])){ $over_sc_mp6 = number_format($csvnew[8][10],2); }else{ $over_sc_mp6 = '-';  }
						if(is_numeric($over_sc_mp2)){ $over_sc_mp_chart2 = $over_sc_mp2; }else{ $over_sc_mp_chart2 = '0';  }
						if(is_numeric($over_sc_mp3)){ $over_sc_mp_chart3 = $over_sc_mp3; }else{ $over_sc_mp_chart3 = '0';  }
						if(is_numeric($over_sc_mp4)){ $over_sc_mp_chart4 = $over_sc_mp4; }else{ $over_sc_mp_chart4 = '0';  }
						if(is_numeric($over_sc_mp5)){ $over_sc_mp_chart5 = $over_sc_mp5; }else{ $over_sc_mp_chart5 = '0';  }
						if(is_numeric($over_sc_mp6)){ $over_sc_mp_chart6 = $over_sc_mp6; }else{ $over_sc_mp_chart6 = '0';  }
						$over_sc_sp1 = 'S&P Small Cap 600 Index<sup>7</sup>'; 
						if(is_numeric($csvnew[10][5])){ $over_sc_sp2 = number_format($csvnew[10][5],2); }else{ $over_sc_sp2 = '-';  }
                        if(is_numeric($csvnew[10][7])){ $over_sc_sp3 = number_format($csvnew[10][7],2); }else{ $over_sc_sp3 = '-';  }
                        if(is_numeric($csvnew[10][8])){ $over_sc_sp4 = number_format($csvnew[10][8],2); }else{ $over_sc_sp4 = '-';  }
                        if(is_numeric($csvnew[10][9])){ $over_sc_sp5 = number_format($csvnew[10][9],2); }else{ $over_sc_sp5 = '-';  }
                        if(is_numeric($csvnew[10][10])){ $over_sc_sp6 = number_format($csvnew[10][10],2); }else{ $over_sc_sp6 = '-';  }
						if(is_numeric($over_sc_sp2)){ $over_sc_sp_chart2 = $over_sc_sp2; }else{ $over_sc_sp_chart2 = '0';  }
						if(is_numeric($over_sc_sp3)){ $over_sc_sp_chart3 = $over_sc_sp3; }else{ $over_sc_sp_chart3 = '0';  }
						if(is_numeric($over_sc_sp4)){ $over_sc_sp_chart4 = $over_sc_sp4; }else{ $over_sc_sp_chart4 = '0';  }
						if(is_numeric($over_sc_sp5)){ $over_sc_sp_chart5 = $over_sc_sp5; }else{ $over_sc_sp_chart5 = '0';  }
						if(is_numeric($over_sc_sp6)){ $over_sc_sp_chart6 = $over_sc_sp6; }else{ $over_sc_sp_chart6 = '0';  }
						$over_sc_morn1 = 'Morningstar Small Blend Category<sup>8</sup>';
						if(is_numeric($csvnew[13][5])){ $over_sc_morn2 = number_format($csvnew[13][5],2); }else{ $over_sc_morn2 = '-';  }
                        if(is_numeric($csvnew[13][7])){ $over_sc_morn3 = number_format($csvnew[13][7],2); }else{ $over_sc_morn3 = '-';  }
                        if(is_numeric($csvnew[13][8])){ $over_sc_morn4 = number_format($csvnew[13][8],2); }else{ $over_sc_morn4 = '-';  }
                        if(is_numeric($csvnew[13][9])){ $over_sc_morn5 = number_format($csvnew[13][9],2); }else{ $over_sc_morn5 = '-';  }
                        if(is_numeric($csvnew[13][10])){ $over_sc_morn6 = number_format($csvnew[13][10],2); }else{ $over_sc_morn6 = '-';  }
						if(is_numeric($over_sc_morn2)){ $over_sc_morn_chart2 = $over_sc_morn2; }else{ $over_sc_morn_chart2 = '0';  }
						if(is_numeric($over_sc_morn3)){ $over_sc_morn_chart3 = $over_sc_morn3; }else{ $over_sc_morn_chart3 = '0';  }
						if(is_numeric($over_sc_morn4)){ $over_sc_morn_chart4 = $over_sc_morn4; }else{ $over_sc_morn_chart4 = '0';  }
						if(is_numeric($over_sc_morn5)){ $over_sc_morn_chart5 = $over_sc_morn5; }else{ $over_sc_morn_chart5 = '0';  }
						if(is_numeric($over_sc_morn6)){ $over_sc_morn_chart6 = $over_sc_morn6; }else{ $over_sc_morn_chart6 = '0';  }
						
						$expense1 = $csv[4][0];
						$expense2 = $csv[4][1];
						$daily_header_date = 'As of '.$csv_daily[1][2].': NAV - Daily Closing Price';
						$home_nav_title = 'CLOSING PRICES (NAV) as of '.$csv_daily[1][2];
						$daily_fund_ticker = $csv_daily[2][0];
						$daily_nav = '$'.$csv_daily[2][1];
						$daily_fund_ticker2 = $csv_daily[3][0];
						$daily_nav2 = '$'.$csv_daily[3][1];
						$daily_fund_ticker3 = $csv_daily[1][0];
						$daily_nav3 = '$'.$csv_daily[1][1];
						$dist_hist_l1 = 'RECORD DATE';
						$dist_hist_l2 = 'EX-DIVIDEND PAYABLE/REINVEST<br> DATE';
						$dist_hist_l3 = 'REINVEST NAV';
						$dist_hist_l4 = 'DIVIDEND PER SHARE';
						$dist_hist_l5 = 'SHORT-TERM CAPITAL<br> GAINS';
						$dist_hist_l6 = 'LONG-TERM CAPITAL<br> GAINS';
						$dist_hist_vrow1 = $csv[173][1];
						$dist_hist_vrow2 = $csv[174][1];
						$dist_hist_vrow3 = $csv[175][1];
						$dist_hist_vrow4 = $csv[176][1];
						$dist_hist_vrow5 = $csv[177][1];
						$dist_hist_vrow6 = $csv[178][1];
						$dist_hist_vsrow1 = $csv[179][1];
						$dist_hist_vsrow2 = $csv[180][1];
						$dist_hist_vsrow3 = $csv[181][1];
						$dist_hist_vsrow4 = $csv[182][1];
						$dist_hist_vsrow5 = $csv[183][1];
						$dist_hist_vsrow6 = $csv[184][1];
						
						
						
						
						
					$writefileName = 'growth_fund.csv';
					
					$fp = fopen(dirname(__FILE__).'/'.$writefileName,'w');
					//$fp_morningstar = fopen(dirname(__FILE__).'/'.$morningstar,'w');	//$key
				$csv = array_map('array_filter', $csv);
					$csv = array_filter($csv);   
					$eql_fun = array();
					$growth_page = array();

					$growth_page[0] = array($as_of_per);
					$growth_page[1] = array('FUND/INDEX', '1 YR', '5 YR', '10 YR', '20 YR', 'SINCE INCEPTION');
					$growth_page[2] = array($amp1, $over_amp2, $over_amp3, $over_amp4, $over_amp5, $over_amp6);
					$growth_page[3] = array($asp1, $over_asp2, $over_asp3, $over_asp4, $over_asp5, $over_asp6);
					$growth_page[4] = array($alm1, $over_alm2, $over_alm3, $over_alm4, $over_alm5, $over_alm6);
					$growth_page[6] = array($per1, $per2, $per3, $per4, $per5, $per6, $per7);
					$growth_page[7] = array($yr1, $yr2, $yr3, $yr4, $yr5, $yr6, $yr7);
					$growth_page[8] = array($mpgf1, $mpgf2, $mpgf3, $mpgf4, $mpgf5, $mpgf6, $mpgf7);
					$growth_page[9] = array($sp1, $sp2, $sp3, $sp4, $sp5, $sp6, $sp7);
					$growth_page[10] = array($lmc1, $lmc2, $lmc3, $lmc4, $lmc5, $lmc6, $lmc7);
					$growth_page[11] = array($as_of_per);
					$growth_page[12] = array('1 YR', '5 YR', '10 YR', '20 YR', 'SINCE INCEPTION');

					$growth_page[13] = array($over_amp_chart2, $over_amp_chart3, $over_amp_chart4, $over_amp_chart5, $over_amp_chart6);
					$growth_page[14] = array($over_asp_chart2, $over_asp_chart3, $over_asp_chart4, $over_asp_chart5, $over_asp_chart6);
					$growth_page[15] = array($over_alm_chart2, $over_alm_chart3, $over_alm_chart4, $over_alm_chart5, $over_alm_chart6);
					$growth_page[16] = array('&nbsp;','&nbsp;');
					$growth_page[17] = array($sweight1, $sweight2, $sweight3, $sweight4, $sweight5, $sweight6, $sweight7, $sweight8, $sweight9, $sweight10, $sweight11, $sweight12);
					$growth_page[18] = array($swv1, $swv2, $swv3, $swv4, $swv5, $swv6, $swv7, $swv8, $swv9, $swv10, $swv11);
					$growth_page[19] = array('&nbsp;','&nbsp;');
					$growth_page[20] = array($mcap1, $mcap2, $mcap3);
					$growth_page[21] = array($mcapv1, $mcapv2, $mcapv3);
					$growth_page[22] = array('&nbsp;','&nbsp;');
					$growth_page[23] = array($geo1, $geo2, $geo3);
					$growth_page[24] = array($geov1, $geov2, $geov3);
					$growth_page[25] = array('&nbsp;','&nbsp;');
					$growth_page[26] = array($asset1, $asset2);
					$growth_page[27] = array($assetv1, $assetv2);
					$growth_page[28] = array('&nbsp;','&nbsp;');
					$growth_page[29] = array('TOP 10 HOLDINGS','% PORTFOLIO');
						
					$growth_page[30] = array($hold_l1, $hold_v1);		
					$growth_page[31] = array($hold_l2, $hold_v2);		
					$growth_page[32] = array($hold_l3, $hold_v3);		
					$growth_page[33] = array($hold_l4, $hold_v4);		
					$growth_page[34] = array($hold_l5, $hold_v5);		
					$growth_page[35] = array($hold_l6, $hold_v6);		
					$growth_page[36] = array($hold_l7, $hold_v7);		
					$growth_page[37] = array($hold_l8, $hold_v8);		
					$growth_page[38] = array($hold_l9, $hold_v9);		
					$growth_page[39] = array($hold_l10, $hold_v10);	
					$growth_page[40] = array('&nbsp;','&nbsp;');		
					
					$growth_page[41] = array('&nbsp;','&nbsp;');
					$growth_page[42] = array($ff_date);
					$growth_page[43] = array($ff1, $ffv1);
					$growth_page[44] = array($ff2, $ffv2);
					$growth_page[45] = array($ff3, $ffv3);
					$growth_page[46] = array($ff4, $ffv4);
					$growth_page[47] = array($ff5, $ffv5);
					$growth_page[48] = array($ff6, $ffv6);
					$growth_page[49] = array($ff7, $ffv7);
					$growth_page[50] = array($ff8, $ffv8);
					$growth_page[51] = array($ff9, $ffv9);
					$growth_page[52] = array($ff10, $ffv10);
					$growth_page[53] = array($ff11, $ffv11);
					$growth_page[54] = array($ff12, $ffv12);
					$growth_page[55] = array($ff13, $ffv13);
					$growth_page[56] = array($ff14, $ffv14);
					$growth_page[57] = array($ff15, $ffv15);
					$growth_page[58] = array($ff16, $ffv16);
					$growth_page[59] = array($ff17, $ffv17);
					$growth_page[60] = array($ff18, $ffv18);
					$growth_page[61] = array('', 'SECTOR WEIGHTS','% PORTFOLIO');
					$growth_page[62] = array('', $sweight1, $sweightv1);
					$growth_page[63] = array('', $sweight2, $sweightv2);
					$growth_page[64] = array('', $sweight3, $sweightv3);
					$growth_page[65] = array('', $sweight4, $sweightv4);
					$growth_page[66] = array('', $sweight5, $sweightv5);
					$growth_page[67] = array('', $sweight6, $sweightv6);
					$growth_page[68] = array('', $sweight7, $sweightv7);
					$growth_page[69] = array('', $sweight8, $sweightv8);
					$growth_page[70] = array('', $sweight9, $sweightv9);
					$growth_page[71] = array('', $sweight10, $sweightv10);
					$growth_page[72] = array('', $sweight11, $sweightv11);
					$growth_page[73] = array('', $sweight12, $sweightv12);
					$growth_page[74] = array('&nbsp;','&nbsp;');
					$growth_page[75] = array($morn1);
					$growth_page[76] = array('', 'OVERALL', '1 YR', '3 YR', '5 YR', '10 YR', 'Since Inception');
					$growth_page[77] = array('Star Rating',$morn_sr_star1, $morn_sr_star2, $morn_sr_star3, $morn_sr_star4, $morn_sr_star5, $morn_sr_star6);
					$growth_page[78] = array('Funds in Category', $morn_fc1, $morn_fc2, $morn_fc3, $morn_fc4, $morn_fc5, $morn_fc6);	
					$growth_page[79] = array('Percentile Rank', $morn_pr1, $morn_pr2, $morn_pr3, $morn_pr4, $morn_pr5, $morn_pr6);	
					$growth_page[80] = array('Funds in Category', $morn_fic1, $morn_fic2, $morn_fic3, $morn_fic4, $morn_fic5, $morn_fic6);
					$growth_page[81] = array('&nbsp;','&nbsp;');
					$growth_page[82] = array('PERIOD', 'DATE RANGE');	
					$growth_page[83] = array($per1,$yr1);	
					$growth_page[84] = array($per2,$yr2);
					$growth_page[85] = array($per3,$yr3);	
					$growth_page[86] = array($per4,$yr4);	
					$growth_page[97] = array($per5,$yr5);	
					$growth_page[98] = array($per6,$yr6);	
					$growth_page[99] = array($per7,$yr7);
					$growth_page[100] = array('&nbsp;','&nbsp;');		
					$growth_page[101] = array($expense1);		
					$growth_page[102] = array($expense2);	
					$growth_page[103] = array('&nbsp;','&nbsp;');	
					$growth_page[104] = array($daily_header_date);	
					$growth_page[105] = array('Growth Fund', $daily_fund_ticker, $daily_nav);
					$growth_page[106] = array($home_nav_title);	
					$growth_page[107] = array('Growth Fund', $daily_fund_ticker, $daily_nav);
					$growth_page[108] = array('Balanced Fund', $daily_fund_ticker2, $daily_nav2);
					$growth_page[109] = array('Small Cap Fund', $daily_fund_ticker3, $daily_nav3);
					$growth_page[110] = array('&nbsp;','&nbsp;');
					$growth_page[111] = array($dist_hist_l1, $dist_hist_l2, $dist_hist_l3, $dist_hist_l4, $dist_hist_l5, $dist_hist_l6);
					$growth_page[112] = array($dist_hist_vrow1, $dist_hist_vrow2, $dist_hist_vrow3, $dist_hist_vrow4, $dist_hist_vrow5, $dist_hist_vrow6);
					$growth_page[113] = array($dist_hist_vsrow1, $dist_hist_vsrow2, $dist_hist_vsrow3, $dist_hist_vsrow4, $dist_hist_vsrow5, $dist_hist_vsrow6);
					
					fclose($fp);
					array_walk_recursive($growth_page, "removeMyNA");
					function removeMyNA(&$element, $index){ $element = str_replace("N/A", "-", $element); }
					
					$fpe = fopen(dirname(__FILE__).'/'.$writefileName,'w');
					foreach($growth_page AS $key => $vls){
					fputcsv($fpe, $vls, ',', " ", '"');
				}
				fclose($fpe);
				
				$morningstar = 'overview.csv';
				$overview_page[0] = $over_label;
				$overview_page[1] = array($over_amp1, $over_amp2, $over_amp3, $over_amp4, $over_amp5, $over_amp6);
				$overview_page[2] = array($over_asp1, $over_asp2, $over_asp3, $over_asp4, $over_asp5, $over_asp6);
				$overview_page[3] = array($over_alm1, $over_alm2, $over_alm3, $over_alm4, $over_alm5, $over_alm6);
				$overview_page[4] = array('&nbsp;','&nbsp;');
				$overview_page[5] = array($over_bal_mp1, $over_bal_mp2, $over_bal_mp3, $over_bal_mp4, $over_bal_mp5, $over_bal_mp6);
				$overview_page[6] = array($over_bal_com1, $over_bal_com2, $over_bal_com3, $over_bal_com4, $over_bal_com5, $over_bal_com6);
				$overview_page[7] = array($over_bal_morn1, $over_bal_morn2, $over_bal_morn3, $over_bal_morn4, $over_bal_morn5, $over_bal_morn6);
				$overview_page[8] = array($over_bal_sp1, $over_bal_sp2, $over_bal_sp3, $over_bal_sp4, $over_bal_sp5, $over_bal_sp6);
				$overview_page[9] = array($over_bal_bloom1, $over_bal_bloom2, $over_bal_bloom3, $over_bal_bloom4, $over_bal_bloom5, $over_bal_bloom6);
				$overview_page[10] = array('&nbsp;','&nbsp;');
				$overview_page[11] = array($over_sc_mp1, $over_sc_mp2, $over_sc_mp3, $over_sc_mp4, $over_sc_mp5, $over_sc_mp6);
				$overview_page[12] = array($over_sc_sp1, $over_sc_sp2, $over_sc_sp3, $over_sc_sp4, $over_sc_sp5, $over_sc_sp6);
				$overview_page[13] = array($over_sc_morn1, $over_sc_morn2, $over_sc_morn3, $over_sc_morn4, $over_sc_morn5, $over_sc_morn6);
				
				$newmvls = array();

array_walk_recursive($overview_page, "removeMy");
function removeMy(&$element, $index){ $element = str_replace("N/A", "-", $element); }

				$fpe_morningstar = fopen(dirname(__FILE__).'/'.$morningstar,'w');
					foreach($overview_page AS $key => $msvls){
						
					fputcsv($fpe_morningstar, $msvls, ',', ' ', '"');
				}
				fclose($fpe_morningstar);
				
					$top_holdings = 'growth-holding-and-fund-fact.csv';
					$hold_ff[0] = array('TOP 10 HOLDINGS','% PORTFOLIO');
					$hold_ff[1] = array($hold_l1, $hold_v1);		
					$hold_ff[2] = array($hold_l2, $hold_v2);		
					$hold_ff[3] = array($hold_l3, $hold_v3);		
					$hold_ff[4] = array($hold_l4, $hold_v4);		
					$hold_ff[5] = array($hold_l5, $hold_v5);		
					$hold_ff[6] = array($hold_l6, $hold_v6);		
					$hold_ff[7] = array($hold_l7, $hold_v7);		
					$hold_ff[8] = array($hold_l8, $hold_v8);		
					$hold_ff[9] = array($hold_l9, $hold_v9);		
					$hold_ff[10] = array($hold_l10, $hold_v10);	
					$hold_ff[11] = array('&nbsp;','&nbsp;');
					$hold_ff[12] = array('&nbsp;','&nbsp;');
					$hold_ff[13] = array($ff_date);
					$hold_ff[14] = array($ff1, $ffv1);
					$hold_ff[15] = array($ff2, $ffv2);
					$hold_ff[16] = array($ff3, $ffv3);
					$hold_ff[17] = array($ff4, $ffv4);
					$hold_ff[18] = array($ff5, $ffv5);
					$hold_ff[19] = array($ff6, $ffv6);
					$hold_ff[20] = array($ff7, $ffv7);
					$hold_ff[21] = array($ff8, $ffv8);
					$hold_ff[22] = array($ff9, $ffv9);
					$hold_ff[23] = array($ff10, $ffv10);
					$hold_ff[24] = array($ff11, $ffv11);
					$hold_ff[25] = array($ff12, $ffv12);
					$hold_ff[26] = array($ff13, $ffv13);
					$hold_ff[27] = array($ff14, $ffv14);
					$hold_ff[28] = array($ff15, $ffv15);
					$hold_ff[29] = array($ff16, $ffv16);
					$hold_ff[30] = array($ff17, $ffv17);
					$hold_ff[31] = array($ff18, $ffv18);
					
				
				$file_loc_top_hold = fopen(dirname(__FILE__).'/'.$top_holdings,'w');
					foreach($hold_ff AS $hkey => $hvls){
						
					fputcsv($file_loc_top_hold, $hvls, '	', ' ', '"');
				}
				fclose($file_loc_top_hold);
				

echo '<pre>';
print_r($growth_page);
echo '</pre>';
