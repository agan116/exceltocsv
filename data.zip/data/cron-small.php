<?php
		$excel_lib = '/var/www/html/mp/cronfiles/data/Classes/PHPExcel/IOFactory.php';
		//$excel_lib = '/home/mairsand/public_html/templates/tabulizer/data/Classes/PHPExcel/IOFactory.php';
		include($excel_lib);
		$filearray = array('small-cap-fund-data.xlsx','MP_Quarterly_FTP.csv','MP_Daily_FTP.csv');

			// open file
			
			//$file2 = fopen('/home/mairsand/public_html/datafeed/'.$filearray[1],"r");
			//$file_daily = fopen('/home/mairsand/public_html/datafeed/'.$filearray[2],"r");
			$file2 = fopen(dirname(__FILE__).'/'.$filearray[1],"r");
			$file_daily = fopen(dirname(__FILE__).'/'.$filearray[2],"r");
			if (!$file2) {
				echo "File not exisit";
			}

			$csv = array();
			$omit = array();
			$omit2 = array(1,2,4);
			$omit3 = array(2,3,4);
			
			 try {
		$inputFileType1 = PHPExcel_IOFactory::identify($filearray[0]);
		$objReader1 = PHPExcel_IOFactory::createReader($inputFileType1);
		$objPHPExcel1 = $objReader1->load($filearray[0]);
		 } catch (Exception $e) {
    die('Error loading file "' . pathinfo($filearray[0], PATHINFO_BASENAME) . '": ' . 
        $e->getMessage());
  }
		$sheet1 = $objPHPExcel1->getSheet(0);
		$highestRow1 = $sheet1->getHighestRow();
		$highestColumn1 = $sheet1->getHighestColumn();
		$rowData1 = array();
		 for ($row1 = 1; $row1 <= $highestRow1; $row1++) { 
    $rowData1[] = $sheet1->rangeToArray('A' . $row1 . ':' . $highestColumn1 . $row1, null, true, true);
  }
   foreach($rowData1 AS $k => $v){
	  foreach ($v AS $fk => $fv){
		  $csv[] = $fv;
		  }
	  }

					while( ($row2 = fgetcsv($file2)) !== FALSE){
						 $array_without2 = array_diff_key($row2, array_flip($omit2));		 
						 $csvnew[] = $array_without2;
					} 
					while( ($row3 = fgetcsv($file_daily)) !== FALSE){
						 $array_without3 = array_diff_key($row3, array_flip($omit));		 
						 $csv_daily[] = $array_without3;
					} 

					fclose($file);
						$as_of = $csv[4][0];
						$as_of_per = 'As of '.$csvnew[1][0];
						$per1 = $csv[9][1];
						$per2 = $csv[13][1];
						$per3 = $csv[17][1];
						$per4 = $csv[21][1];
						$per5 = $csv[25][1];
						$per6 = $csv[29][1];
						$per7 = $csv[33][1];
						$yr1 = $csv[9][3];
						$yr2 = $csv[13][3];
						$yr3 = $csv[17][3];
						$yr4 = $csv[21][3];
						$yr5 = $csv[25][3];
						$yr6 = $csv[29][3];
						$yr7 = $csv[33][3];
						$mpgf1 = $csv[10][1];
						$mpgf2 = $csv[14][1];
						$mpgf3 = $csv[18][1];
						$mpgf4 = $csv[22][1];
						$mpgf5 = $csv[26][1];
						$mpgf6 = $csv[30][1];
						$mpgf7 = $csv[34][1];
						$sp1 = $csv[12][1];
						$sp2 = $csv[16][1];
						$sp3 = $csv[20][1];
						$sp4 = $csv[24][1];
						$sp5 = $csv[28][1];
						$sp6 = $csv[32][1];
						$sp7 = $csv[36][1];
						$lmc1 = $csv[11][1];
						$lmc2 = $csv[15][1];
						$lmc3 = $csv[19][1];
						$lmc4 = $csv[23][1];
						$lmc5 = $csv[27][1];
						$lmc6 = $csv[31][1];
						$lmc7 = $csv[35][1];
						$sweight1 = $csv[88][0];
						$sweight2 = $csv[89][0];
						$sweight3 = $csv[90][0];
						$sweight4 = $csv[91][0];
						$sweight5 = $csv[92][0];
						$sweight6 = $csv[93][0];
						$sweight7 = $csv[94][0];
						$sweight8 = $csv[95][0];
						$sweight9 = $csv[96][0];
						$sweight10 = $csv[97][0];
						$sweight11 = $csv[98][0];
						$sweight12 = $csv[99][0];
						$sweightv1 = number_format($csv[88][1],1);
						$sweightv2 = number_format($csv[89][1],1);
						$sweightv3 = number_format($csv[90][1],1);
						$sweightv4 = number_format($csv[91][1],1);
						$sweightv5 = number_format($csv[92][1],1);
						$sweightv6 = number_format($csv[93][1],1);
						$sweightv7 = number_format($csv[94][1],1);
						$sweightv8 = number_format($csv[95][1],1);
						$sweightv9 = number_format($csv[96][1],1);
						$sweightv10 = number_format($csv[97][1],1);
						$sweightv11 = number_format($csv[98][1],1);
						$sweightv12 = number_format($csv[99][1],1);
						$swv1 = $csv[158][1];
						$swv2 = $csv[159][1];
						$swv3 = $csv[160][1];
						$swv4 = $csv[161][1];
						$swv5 = $csv[162][1];
						$swv6 = $csv[163][1];
						$swv7 = $csv[164][1];
						$swv8 = $csv[165][1];
						$swv9 = $csv[166][1];
						$swv10 = $csv[167][1];
						$swv11 = $csv[168][1];
						$hold_title = $csv[102][0];
						$hold_l1 = $csv[103][0];
						$hold_l2 = $csv[104][0];
						$hold_l3 = $csv[105][0];
						$hold_l4 = $csv[106][0];
						$hold_l5 = $csv[107][0];
						$hold_l6 = $csv[108][0];
						$hold_l7 = $csv[109][0];
						$hold_l8 = $csv[110][0];
						$hold_l9 = $csv[111][0];
						$hold_l10 = $csv[112][0];
						$hold_v1 = number_format($csv[103][1],1);
						$hold_v2 = number_format($csv[104][1],1);
						$hold_v3 = number_format($csv[105][1],1);
						$hold_v4 = number_format($csv[106][1],1);
						$hold_v5 = number_format($csv[107][1],1);
						$hold_v6 = number_format($csv[108][1],1);
						$hold_v7 = number_format($csv[109][1],1);
						$hold_v8 = number_format($csv[110][1],1);
						$hold_v9 = number_format($csv[111][1],1);
						$hold_v10 = number_format($csv[112][1],1);
						$mcap1 = $csv[132][0].' '.$csv[132][1];
						$mcap2 = $csv[133][0].' '.$csv[133][1];
						$mcap3 = $csv[134][0].' '.$csv[134][1];
						$mcapv1 = trim($csv[132][1],'%');
						$mcapv2 = trim($csv[133][1],'%');
						$mcapv3 = trim($csv[134][1],'%');
						$geo1 = $csv[138][0].' '.$csv[138][1];
						$geo2 = $csv[139][0].' '.$csv[139][1];
						$geo3 = $csv[140][0].' '.$csv[140][1];
						$geov1 = trim($csv[138][1],'%');
						$geov2 = trim($csv[139][1],'%');
						$geov3 = trim($csv[140][1],'%');
						$asset1 = $csv[144][0].' '.$csv[144][1];
						$asset2 = $csv[149][0].' '.$csv[149][1];
						$assetv1 = trim($csv[144][1],'%');
						$assetv2 = trim($csv[149][1],'%');
						$ff_date = 'As of '.$csv[1][1].':';

						$ff1 = 'Ticker';
						$ff2 = 'Inception Date';
						$ff3 = 'Style';
						$ff4 = 'Holdings';
						$ff5 = 'Annualized Turnover<sup>5</sup>';
						$ff6 = 'Expense Ratio';
						$ff7 = 'Active Share<sup>6</sup>';
						$ff8 = 'Sharpe Ratio<sup>7</sup>';
						$ff9 = 'Net Asset Value<sup>8</sup>';
						$ff10 = 'Wtd. Ave. Market Cap<sup>9</sup>';
						$ff11 = '30-Day SEC Yield<sup>10</sup>';
						$ff12 = 'Total Net Assets';
						$ff13 = 'Sales Charge<sup>1</sup>';
						$ff14 = 'Min. Initial Investment';
						$ff15 = 'Min. Initial IRA Investment';
						$ff16 = 'Subsequent Investment';
						$ff17 = 'Income Distributions';
						$ff18 = 'Capital Gains Distributions';
						
						$ffv1 = $csv[63][1];
						$ffv2 = $csv[64][1];
						$ffv3 = $csv[65][1];
						$ffv4 = $csv[66][1];
						$ffv5 = $csv[67][1];
						$ffv6 = $csv[68][1];
						$ffv7 = $csv[70][1];
						$ffv8 = $csv[71][1];
						$ffv9 = $csv[72][1];
						$ffv10 = $csv[73][1];
						$ffv11 = $csv[75][1];
						$ffv12 = $csv[78][1];
						$ffv13 = $csv[79][1];
						$ffv14 = $csv[80][1];
						$ffv15 = $csv[81][1];
						$ffv16 = $csv[82][1];
						$ffv17 = $csv[83][1];
						$ffv18 = $csv[84][1];
						

						$over_sc_morn6 = $csvnew[13][10];
						$morn1 = 'As of '.$csv[1][1].' among Small Blend Funds based on risk-adjusted returns.';
						$morn_sr1 = $csv[40][1];
						if($morn_sr1 == '1'){$morn_sr_star1='<img src=/images/1Stars.png alt=1star >';}elseif($morn_sr1 == '2'){$morn_sr_star1='<img src=/images/2Stars.png alt=2star >';}elseif($morn_sr1 == '3'){$morn_sr_star1='<img src=/images/3Stars.png alt=3star >';}elseif($morn_sr1 == '4'){$morn_sr_star1='<img src=/images/4Stars.png alt=4star >';}elseif($morn_sr1 == '5'){$morn_sr_star1='<img src=/images/5Stars.png alt=5star >';}else{$morn_sr_star1 = '-';}
						$morn_sr2 = $csv[41][1];
						if($morn_sr2 == '1'){$morn_sr_star2='<img src=/images/1Stars.png alt=1star >';}elseif($morn_sr2 == '2'){$morn_sr_star2='<img src=/images/2Stars.png alt=2star >';}elseif($morn_sr2 == '3'){$morn_sr_star2='<img src=/images/3Stars.png alt=3star >';}elseif($morn_sr2 == '4'){$morn_sr_star2='<img src=/images/4Stars.png alt=4star >';}elseif($morn_sr2 == '5'){$morn_sr_star2='<img src=/images/5Stars.png alt=5star >';}else{$morn_sr_star2 = '-';}
						$morn_sr3 = $csv[42][1];
						if($morn_sr3 == '1'){$morn_sr_star3='<img src=/images/1Stars.png alt=1star >';}elseif($morn_sr3 == '2'){$morn_sr_star3='<img src=/images/2Stars.png alt=2star >';}elseif($morn_sr3 == '3'){$morn_sr_star3='<img src=/images/3Stars.png alt=3star >';}elseif($morn_sr3 == '4'){$morn_sr_star3='<img src=/images/4Stars.png alt=4star >';}elseif($morn_sr3 == '5'){$morn_sr_star3='<img src=/images/5Stars.png alt=5star >';}else{$morn_sr_star3 = '-';}
						$morn_sr4 = $csv[43][1];
						if($morn_sr4 == '1'){$morn_sr_star4='<img src=/images/1Stars.png alt=1star >';}elseif($morn_sr4 == '2'){$morn_sr_star4='<img src=/images/2Stars.png alt=2star >';}elseif($morn_sr4 == '3'){$morn_sr_star4='<img src=/images/3Stars.png alt=3star >';}elseif($morn_sr4 == '4'){$morn_sr_star4='<img src=/images/4Stars.png alt=4star >';}elseif($morn_sr4 == '5'){$morn_sr_star4='<img src=/images/5Stars.png alt=5star >';}else{$morn_sr_star4 = '-';}
						$morn_sr5 = $csv[44][1];
						if($morn_sr5 == '1'){$morn_sr_star5='<img src=/images/1Stars.png alt=1star >';}elseif($morn_sr5 == '2'){$morn_sr_star5='<img src=/images/2Stars.png alt=2star >';}elseif($morn_sr5 == '3'){$morn_sr_star5='<img src=/images/3Stars.png alt=3star >';}elseif($morn_sr5 == '4'){$morn_sr_star5='<img src=/images/4Stars.png alt=4star >';}elseif($morn_sr5 == '5'){$morn_sr_star5='<img src=/images/5Stars.png alt=5star >';}else{$morn_sr_star5 = '-';}
						$morn_sr6 = $csv[44][3];
						if($morn_sr6 == '1'){$morn_sr_star6='<img src=/images/1Stars.png alt=1star >';}elseif($morn_sr6 == '2'){$morn_sr_star6='<img src=/images/2Stars.png alt=2star >';}elseif($morn_sr6 == '3'){$morn_sr_star6='<img src=/images/3Stars.png alt=3star >';}elseif($morn_sr6 == '4'){$morn_sr_star6='<img src=/images/4Stars.png alt=4star >';}elseif($morn_sr6 == '5'){$morn_sr_star6='<img src=/images/5Stars.png alt=5star >';}else{$morn_sr_star6 = '-';}
						$morn_fc1 = $csv[45][1];
						$morn_fc2 = $csv[46][1];
						$morn_fc3 = $csv[47][1];
						$morn_fc4 = $csv[48][1];
						$morn_fc5 = $csv[49][1];
						$morn_fc6 = $csv[49][3];
						$morn_pr1 = $csv[50][1];
						$morn_pr2 = $csv[51][1];
						$morn_pr3 = $csv[52][1];
						$morn_pr4 = $csv[53][1];
						$morn_pr5 = $csv[54][1];
						$morn_pr6 = $csv[54][3];
						$morn_fic1 = $csv[55][1];
						$morn_fic2 = $csv[56][1];
						$morn_fic3 = $csv[57][1];
						$morn_fic4 = $csv[58][1];
						$morn_fic5 = $csv[59][1];
						$morn_fic6 = $csv[59][3];
						
						$over_sc_mp1 = 'Mairs & Power Small Cap Fund<sup>2</sup>'; 
						if(is_numeric($csvnew[8][5])){ $over_sc_mp2 = number_format($csvnew[8][5],2); }else{ $over_sc_mp2 = '-';  }
						if(is_numeric($csvnew[8][7])){ $over_sc_mp3 = number_format($csvnew[8][7],2); }else{ $over_sc_mp3 = '-';  }
						if(is_numeric($csvnew[8][6])){ $over_sc_mp4 = number_format($csvnew[8][6],2); }else{ $over_sc_mp4 = '-';  }
						if(is_numeric($csvnew[8][9])){ $over_sc_mp5 = number_format($csvnew[8][9],2); }else{ $over_sc_mp5 = '-';  }
						if(is_numeric($csvnew[8][10])){ $over_sc_mp6 = number_format($csvnew[8][10],2); }else{ $over_sc_mp6 = '-';  }
						
						if(is_numeric($over_sc_mp2)){ $over_sc_mp_chart2 = $over_sc_mp2; }else{ $over_sc_mp_chart2 = '0';  }
						if(is_numeric($over_sc_mp3)){ $over_sc_mp_chart3 = $over_sc_mp3; }else{ $over_sc_mp_chart3 = '0';  }
						if(is_numeric($over_sc_mp4)){ $over_sc_mp_chart4 = $over_sc_mp4; }else{ $over_sc_mp_chart4 = '0';  }
						if(is_numeric($over_sc_mp5)){ $over_sc_mp_chart5 = $over_sc_mp5; }else{ $over_sc_mp_chart5 = '0';  }
						if(is_numeric($over_sc_mp6)){ $over_sc_mp_chart6 = $over_sc_mp6; }else{ $over_sc_mp_chart6 = '0';  }
						$over_sc_sp1 = 'S&P Small Cap 600 Index<sup>3</sup>'; 
						if(is_numeric($csvnew[10][5])){ $over_sc_sp2 = number_format($csvnew[10][5],2); }else{ $over_sc_sp2 = '-';  }
						if(is_numeric($csvnew[10][7])){ $over_sc_sp3 = number_format($csvnew[10][7],2); }else{ $over_sc_sp3 = '-';  }
						if(is_numeric($csvnew[10][6])){ $over_sc_sp4 = number_format($csvnew[10][6],2); }else{ $over_sc_sp4 = '-';  }
						if(is_numeric($csvnew[10][9])){ $over_sc_sp5 = number_format($csvnew[10][9],2); }else{ $over_sc_sp5 = '-';  }
						if(is_numeric($csvnew[10][10])){ $over_sc_sp6 = number_format($csvnew[10][10],2); }else{ $over_sc_sp6 = '-';  }
						
						if(is_numeric($over_sc_sp2)){ $over_sc_sp_chart2 = $over_sc_sp2; }else{ $over_sc_sp_chart2 = '0';  }
						if(is_numeric($over_sc_sp3)){ $over_sc_sp_chart3 = $over_sc_sp3; }else{ $over_sc_sp_chart3 = '0';  }
						if(is_numeric($over_sc_sp4)){ $over_sc_sp_chart4 = $over_sc_sp4; }else{ $over_sc_sp_chart4 = '0';  }
						if(is_numeric($over_sc_sp5)){ $over_sc_sp_chart5 = $over_sc_sp5; }else{ $over_sc_sp_chart5 = '0';  }
						if(is_numeric($over_sc_sp6)){ $over_sc_sp_chart6 = $over_sc_sp6; }else{ $over_sc_sp_chart6 = '0';  }
						$over_sc_morn1 = 'Morningstar Small Blend Category<sup>4</sup>';
						if(is_numeric($csvnew[13][5])){ $over_sc_morn2 = number_format($csvnew[13][5],2); }else{ $over_sc_morn2 = '-';  }
						if(is_numeric($csvnew[13][7])){ $over_sc_morn3 = number_format($csvnew[13][7],2); }else{ $over_sc_morn3 = '-';  }
						if(is_numeric($csvnew[13][6])){ $over_sc_morn4 = number_format($csvnew[13][6],2); }else{ $over_sc_morn4 = '-';  }
						if(is_numeric($csvnew[13][9])){ $over_sc_morn5 = number_format($csvnew[13][9],2); }else{ $over_sc_morn5 = '-';  }
						if(is_numeric($csvnew[13][10])){ $over_sc_morn6 = number_format($csvnew[13][10],2); }else{ $over_sc_morn6 = '-';  }
					
						if(is_numeric($over_sc_morn2)){ $over_sc_morn_chart2 = $over_sc_morn2; }else{ $over_sc_morn_chart2 = '0';  }
						if(is_numeric($over_sc_morn3)){ $over_sc_morn_chart3 = $over_sc_morn3; }else{ $over_sc_morn_chart3 = '0';  }
						if(is_numeric($over_sc_morn4)){ $over_sc_morn_chart4 = $over_sc_morn4; }else{ $over_sc_morn_chart4 = '0';  }
						if(is_numeric($over_sc_morn5)){ $over_sc_morn_chart5 = $over_sc_morn5; }else{ $over_sc_morn_chart5 = '0';  }
						if(is_numeric($over_sc_morn6)){ $over_sc_morn_chart6 = $over_sc_morn6; }else{ $over_sc_morn_chart6 = '0';  }
						
						$expense1 = $csv[4][0];
						$expense2 = $csv[4][1];
						$daily_header_date = 'As of '.$csv_daily[1][2].': NAV - Daily Closing Price';
						$daily_fund_ticker = $csv_daily[1][0];
						$daily_nav = '$'.$csv_daily[1][1];
						
						$dist_hist_l1 = 'RECORD DATE';
						$dist_hist_l2 = 'EX-DIVIDEND PAYABLE/REINVEST<br> DATE';
						$dist_hist_l3 = 'REINVEST NAV';
						$dist_hist_l4 = 'DIVIDEND PER SHARE';
						$dist_hist_l5 = 'SHORT-TERM CAPITAL<br> GAINS';
						$dist_hist_l6 = 'LONG-TERM CAPITAL<br> GAINS';
						$dist_hist_vrow1 = $csv[173][1];
						$dist_hist_vrow2 = $csv[174][1];
						$dist_hist_vrow3 = $csv[175][1];
						$dist_hist_vrow4 = $csv[176][1];
						$dist_hist_vrow5 = $csv[177][1];
						$dist_hist_vrow6 = $csv[178][1];
						$dist_hist_vsrow1 = $csv[179][1];
						$dist_hist_vsrow2 = $csv[180][1];
						$dist_hist_vsrow3 = $csv[181][1];
						$dist_hist_vsrow4 = $csv[182][1];
						$dist_hist_vsrow5 = $csv[183][1];
						$dist_hist_vsrow6 = $csv[184][1];
	
					$writefileName = 'small_cap_fund.csv';
					
					$fp = fopen(dirname(__FILE__).'/'.$writefileName,'w');
					$csv = array_map('array_filter', $csv);
					$csv = array_filter($csv);   
					$eql_fun = array();
					$small_cap = array();

					$small_cap[0] = array($as_of_per);
					$small_cap[1] = array('FUND/INDEX', '1 YR', '3 YR', '5 YR','SINCE INCEPTION');
					$small_cap[2] = array($over_sc_mp1, $over_sc_mp2, $over_sc_mp4, $over_sc_mp3, $over_sc_mp6);
					$small_cap[3] = array($over_sc_sp1, $over_sc_sp2, $over_sc_sp4, $over_sc_sp3, $over_sc_sp6);
					$small_cap[4] = array($over_sc_morn1, $over_sc_morn2, $over_sc_morn4, $over_sc_morn3, $over_sc_morn6);
					$small_cap[5] = array('&nbsp;','&nbsp;');
					$small_cap[6] = array('1 YR', '3 YR', '5 YR','SINCE INCEPTION');
					$small_cap[7] = array($over_sc_mp_chart2, $over_sc_mp_chart3, $over_sc_mp_chart4, $over_sc_mp_chart6);
					$small_cap[8] = array($over_sc_sp_chart2, $over_sc_sp_chart3, $over_sc_sp_chart4, $over_sc_sp_chart6);
					$small_cap[9] = array($over_sc_morn_chart2, $over_sc_morn_chart3, $over_sc_morn_chart4, $over_sc_morn_chart6);
					$small_cap[10] = array('Sector Allocation');
					$small_cap[12] = array('1 YR', '5 YR', '10 YR', '20 YR', 'SINCE INCEPTION');
					$small_cap[13] = array($sweight1, $sweight2, $sweight3, $sweight4, $sweight5, $sweight6, $sweight7, $sweight8, $sweight9, $sweight10, $sweight11, $sweight12);
					$small_cap[14] = array($swv1, $swv2, $swv3, $swv4, $swv5, $swv6, $swv7, $swv8, $swv9, $swv10, $swv11);
					$small_cap[15] = array('&nbsp;','&nbsp;');
					$small_cap[16] = array($mcap1, $mcap2, $mcap3);
					$small_cap[17] = array($mcapv1, $mcapv2, $mcapv3);
					$small_cap[18] = array('&nbsp;','&nbsp;');
					$small_cap[19] = array($geo1, $geo2, $geo3);
					$small_cap[20] = array($geov1, $geov2, $geov3);
					$small_cap[21] = array('&nbsp;','&nbsp;');
					$small_cap[22] = array($asset1, $asset2);
					$small_cap[23] = array($assetv1, $assetv2);
					$small_cap[24] = array('&nbsp;','&nbsp;');
					$small_cap[25] = array('&nbsp;','&nbsp;');
					$small_cap[26] = array('&nbsp;','&nbsp;');
					$small_cap[27] = array('&nbsp;','&nbsp;');
					$small_cap[28] = array('&nbsp;','&nbsp;');
					$small_cap[28] = array('&nbsp;','&nbsp;');
					$small_cap[29] = array('TOP 10 HOLDINGS','% PORTFOLIO');
					$small_cap[30] = array($hold_l1, $hold_v1);		
					$small_cap[31] = array($hold_l2, $hold_v2);		
					$small_cap[32] = array($hold_l3, $hold_v3);		
					$small_cap[33] = array($hold_l4, $hold_v4);		
					$small_cap[34] = array($hold_l5, $hold_v5);		
					$small_cap[35] = array($hold_l6, $hold_v6);		
					$small_cap[36] = array($hold_l7, $hold_v7);		
					$small_cap[37] = array($hold_l8, $hold_v8);		
					$small_cap[38] = array($hold_l9, $hold_v9);		
					$small_cap[39] = array($hold_l10, $hold_v10);	
					$small_cap[40] = array('&nbsp;','&nbsp;');
					$small_cap[41] = array('&nbsp;','&nbsp;');
					$small_cap[42] = array($ff_date);
					$small_cap[43] = array($ff1, $ffv1);
					$small_cap[44] = array($ff2, $ffv2);
					$small_cap[45] = array($ff3, $ffv3);
					$small_cap[46] = array($ff4, $ffv4);
					$small_cap[47] = array($ff5, $ffv5);
					$small_cap[48] = array($ff6, $ffv6);
					$small_cap[49] = array($ff7, $ffv7);
					$small_cap[50] = array($ff8, $ffv8);
					$small_cap[51] = array($ff9, $ffv9);
					$small_cap[52] = array($ff10, $ffv10);
					$small_cap[53] = array($ff11, $ffv11);
					$small_cap[54] = array($ff12, $ffv12);
					$small_cap[55] = array($ff13, $ffv13);
					$small_cap[56] = array($ff14, $ffv14);
					$small_cap[57] = array($ff15, $ffv15);
					$small_cap[58] = array($ff16, $ffv16);
					$small_cap[59] = array($ff17, $ffv17);
					$small_cap[60] = array($ff18, $ffv18);
					$small_cap[61] = array('', 'SECTOR WEIGHTS','% PORTFOLIO');
					$small_cap[62] = array('', $sweight1, $sweightv1);
					$small_cap[63] = array('', $sweight2, $sweightv2);
					$small_cap[64] = array('', $sweight3, $sweightv3);
					$small_cap[65] = array('', $sweight4, $sweightv4);
					$small_cap[66] = array('', $sweight5, $sweightv5);
					$small_cap[67] = array('', $sweight6, $sweightv6);
					$small_cap[68] = array('', $sweight7, $sweightv7);
					$small_cap[69] = array('', $sweight8, $sweightv8);
					$small_cap[70] = array('', $sweight9, $sweightv9);
					$small_cap[71] = array('', $sweight10, $sweightv10);
					$small_cap[72] = array('', $sweight11, $sweightv11);
					$small_cap[73] = array('', $sweight12, $sweightv12);
					$small_cap[74] = array('&nbsp;','&nbsp;');
					$small_cap[75] = array($morn1);
					$small_cap[76] = array('', 'OVERALL', '1 YR', '3 YR', '5 YR', 'Since Inception');
					$small_cap[77] = array('Star Rating',$morn_sr_star1, $morn_sr_star2, $morn_sr_star3, $morn_sr_star4, $morn_sr_star6);
					$small_cap[78] = array('Funds in Category', $morn_fc1, $morn_fc2, $morn_fc3, $morn_fc4, $morn_fc6);	
					$small_cap[79] = array('Percentile Rank', $morn_pr1, $morn_pr2, $morn_pr3, $morn_pr4, $morn_pr6);	
					$small_cap[80] = array('Funds in Category', $morn_fic1, $morn_fic2, $morn_fic3, $morn_fic4, $morn_fic6);	
					$small_cap[81] = array('&nbsp;','&nbsp;');		
					$small_cap[82] = array($expense1);		
					$small_cap[83] = array($expense2);	
					$small_cap[84] = array('&nbsp;','&nbsp;');	
					$small_cap[85] = array($daily_header_date);	
					$small_cap[86] = array('Small Cap Fund', $daily_fund_ticker, $daily_nav);	
					$small_cap[87] = array('&nbsp;','&nbsp;');
					$small_cap[88] = array($dist_hist_l1, $dist_hist_l2, $dist_hist_l3, $dist_hist_l4, $dist_hist_l5, $dist_hist_l6);
					$small_cap[89] = array($dist_hist_vrow1, $dist_hist_vrow2, $dist_hist_vrow3, $dist_hist_vrow4, $dist_hist_vrow5, $dist_hist_vrow6);
					$small_cap[90] = array($dist_hist_vsrow1, $dist_hist_vsrow2, $dist_hist_vsrow3, $dist_hist_vsrow4, $dist_hist_vsrow5, $dist_hist_vsrow6);
					
					
					fclose($fp);
					array_walk_recursive($small_cap, "removeMyNA");
					function removeMyNA(&$element, $index){ $element = str_replace("N/A", "-", $element); }
					
					$fpe = fopen(dirname(__FILE__).'/'.$writefileName,'w');
					foreach($small_cap AS $key => $vls){
					fputcsv($fpe, $vls, ',', " ", '"');
				}
				fclose($fpe);

				$top_holdings = 'small-holding-and-fund-fact.csv';
					$hold_ff_table[0] = array('&nbsp;','&nbsp;');
					$hold_ff_table[1] = array('Top 10 Equity Holdings','% PORTFOLIO');
					$hold_ff_table[2] = array($hold_l1, $hold_v1);		
					$hold_ff_table[3] = array($hold_l2, $hold_v2);		
					$hold_ff_table[4] = array($hold_l3, $hold_v3);		
					$hold_ff_table[5] = array($hold_l4, $hold_v4);		
					$hold_ff_table[6] = array($hold_l5, $hold_v5);		
					$hold_ff_table[7] = array($hold_l6, $hold_v6);		
					$hold_ff_table[8] = array($hold_l7, $hold_v7);		
					$hold_ff_table[9] = array($hold_l8, $hold_v8);		
					$hold_ff_table[10] = array($hold_l9, $hold_v9);		
					$hold_ff_table[11] = array($hold_l10, $hold_v10);
					$hold_ff_table[12] = array('&nbsp;','&nbsp;');
					$hold_ff_table[13] = array('Fund Fact Table','&nbsp;');
					$hold_ff_table[14] = array($ff_date);
					$hold_ff_table[15] = array($ff1, $ffv1);
					$hold_ff_table[16] = array($ff2, $ffv2);
					$hold_ff_table[17] = array($ff3, $ffv3);
					$hold_ff_table[18] = array($ff4, $ffv4);
					$hold_ff_table[19] = array($ff5, $ffv5);
					$hold_ff_table[20] = array($ff6, $ffv6);
					$hold_ff_table[21] = array($ff7, $ffv7);
					$hold_ff_table[22] = array($ff8, $ffv8);
					$hold_ff_table[23] = array($ff9, $ffv9);
					$hold_ff_table[24] = array($ff10, $ffv10);
					$hold_ff_table[25] = array($ff11, $ffv11);
					$hold_ff_table[26] = array($ff12, $ffv12);
					$hold_ff_table[27] = array($ff13, $ffv13);
					$hold_ff_table[28] = array($ff14, $ffv14);
					$hold_ff_table[29] = array($ff15, $ffv15);
					$hold_ff_table[30] = array($ff16, $ffv16);
					$hold_ff_table[31] = array($ff17, $ffv17);
					$hold_ff_table[32] = array($ff18, $ffv18);

				
				$file_loc_top_hold = fopen(dirname(__FILE__).'/'.$top_holdings,'w');
					foreach($hold_ff_table AS $hkey => $hvls){
						
					fputcsv($file_loc_top_hold, $hvls, '	', ' ', '"');
				}
				fclose($file_loc_top_hold);

echo '<pre>';
print_r($hold_ff_table);
echo '</pre>';
